/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package palindrome;

/**
 *
 * @author ESHOP
 */
import java.util.Scanner;
public class Palindrome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
      String str=input.next();
      int left=0;
      int right=str.length()-1;
      boolean palindrome=true;
      while(left<=right){
          if(str.charAt(left)!=str.charAt(right)){
 
              palindrome=false;
              break;
          }
          else{
          left++;
          right--;
        }
      }
      if(palindrome==true){
          System.out.println("Palindrome ");
      }else{
          System.out.println("not palindrome");}
    }
    
}
