/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package doublylinkedlist;
public class Doublylinkedlist {
    public class Node{
      int data;
      Node next;
      Node pre;
      Node(int data){
          this.data=data;
          this.next=null;
          this.pre=null;          
      }
  }
    private Node head;
   private Node tail;
  Doublylinkedlist(){
      this.head=null;
      this.tail=null;             
    }
  public void insertatstart(int data){
      Node newnode=new Node(data);
      if(head==null){
          head=tail=newnode;
      }else{
          newnode.next=head;
          head.pre=newnode;
          head=newnode;
      }
  }
  public void insertatposition(int position, int data){
  Node current=head;
  Node temp; 
   Node newnode=new Node(data);
  int count=0;
  while(current!=null){
   count++;
if(count==position){
  temp=current.next;  
  current.next=newnode;
   newnode.pre=current;
  newnode.next=temp;
  temp.pre=newnode;
}   
   current=current.next; 
  } 
  }
    public void insertatlast(int data){
      Node newnode=new Node(data);
      if(head==null){
          head=tail=newnode;
      }else{
          tail.next=newnode;
          newnode.pre=tail;
          tail=newnode;
      }
  }
    public void search(int key){
  boolean found=false;
 Node current=head;
 while(current!=null){
     if(key==current.data){
         found=true;     
     }
     current=current.next;   
 }
  if(found==true) {
      System.out.println("Found");
  }else{
      System.out.println("Not found");
  }  
   
        
        
        
    }
    public void deletefromstart(){
     if(head==null){
          System.out.println("Deleted");
          return;
      }
      head=head.next;
      head.pre=null;
}
     public void deleteatposition(int value){
  Node current=head; 
  while(current!=null){
if(value==current.data){
current.pre.next=current.next;
current.next.pre=current.pre;
}   
   current=current.next; 
  }
     }
     public void deletefromlast(){
     if(tail==null){
          System.out.println("Deleted");
          return;
      }
      tail=tail.pre;
      tail.next = null;
}    
    
    public void display(){
     Node current=head;
     while(current!=null){
    System.out.print(current.data+"->");
    current=current.next;
}   
    }
        public void displayfromlast(){
     Node current=tail;
     while(current!=null){
    System.out.print(current.data+ "->");
    current=current.pre;
} }
  public void Size(){
   int size=0;
   Node current=head;
   while(current!=null){
      size++;
      current=current.next;
   }
        System.out.println("The Size of the doublylinkedlist is: "+size);     
    }
        
    public static void main(String[] args) {
      Doublylinkedlist dl2=new Doublylinkedlist();
      dl2.insertatstart(20);
      dl2.insertatstart(30);
      dl2.insertatstart(40);
     dl2.insertatposition(1, 35);
      dl2.insertatstart(50);
      dl2.insertatstart(60);
      dl2.display();
        System.out.println("");
      dl2.deletefromstart();
      dl2.display();
       System.out.println("");
      dl2.deletefromlast();
       dl2.display();
      System.out.println("");
      dl2.deleteatposition(35);
       dl2.display();
        System.out.println("");
        dl2.search(20);
       dl2.Size();
    }
    
}
