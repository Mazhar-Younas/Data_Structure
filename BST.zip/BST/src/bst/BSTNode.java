/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bst;
public class BSTNode {
 public int data;
public BSTNode left;
public BSTNode right;

    public BSTNode(int data) {
        this.data=data;
        this.left=null;
        this.right=null;
    }

}
